<?php
namespace App\Controllers\Api;
class VisitController {
    // spec-compliant endpoints
}