<?php
namespace App\Filters;
class ApiAuthFilter {
    // spec-compliant token check
}