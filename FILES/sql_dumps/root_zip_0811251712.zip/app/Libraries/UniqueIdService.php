<?php namespace App\Libraries;

class UniqueIdService
{
    // Reserved for future enhancements.
}
