# Vet CI4 Overlay (Fresh Start)

Use this overlay on top of a clean CodeIgniter 4 install. See `docs/INSTALL_SUBDOMAIN.md` for exact steps.
