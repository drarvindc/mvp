-- 001_species.sql
INSERT IGNORE INTO species (name) VALUES
('Canine'),
('Feline'),
('Avian'),
('Tortoise'),
('Exotic');
